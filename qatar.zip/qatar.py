# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import os
import numpy as np
import pandas as pd
from operator import itemgetter
from random import randint, random, shuffle, choice


class Qatar:
    
    def __init__(self, path, dataset = None, random_init = False, remove_meta_data = False, 
                 islands = 10, island_size = 10, niter = 5000, niter_migrate = 20):
        os.chdir(path)
        self.islands = islands
        self.island_size = island_size
        self.niter = niter
        self.niter_migrate = niter_migrate
        if remove_meta_data:
            try: remove_meta(path)
            except: print("Erro Limpeza")
        try: self.qatar = pd.read_csv("qatar_file.txt", delimiter=" ", header = None, index_col = 0)
        except: 
            print("Erro: Na leitura de dados")
            self.qatar = None
            
        if self.qatar is not None:
            self.n_total = self.qatar.shape[0]
            self.dists = self.distance_matrix()
            if dataset is None: 
                if not random_init: self.popul = self.create_islands()
                else: self.popul = self.random_init()
            else: self.popul = dataset
            self.fitness_all = self.fitness_indivs()
            #print(self.fitness_all[0])
            
            
            
    def distance_matrix(self):
        dists = []
        for i in range(1,len(self.qatar)):
            for j in range(i+1,len(self.qatar)+1):
                dist_ij = (((self.qatar.loc[i,1] - self.qatar.loc[j,1])**2 
                           + (self.qatar.loc[i,2] - self.qatar.loc[j,2])**2))**(0.5)
                dists.append([i,j,dist_ij])
        return np.asarray(dists)
        # este array, que é uma matriz triangular, so tera as distancias da cidade com index menor para a cidade de index maior
        # evitando-se ter dados repetidos pois a direção inversa é igual,e calculos de distancia a si próprio
    
    def index_distance(self, x1, x2):
        menor = min(x1,x2)
        maior = max(x1,x2)
        index = int((menor-1)*(self.n_total) + maior - ((1+menor)/2)*(menor) - 1)
        #index na lista de tamanhos:
        #verifca qual dos indexes é menor e maior
        #(menor-1)*(self.n_total) verifica o nº de todas as posições da matriz até a linha anterior
        # (+ maior) vai até ao lugar da matriz que a distancia estaria se todas as possibilidades fossem calculadas
        # - ((1+menor)/2)*(menor) - 1: retira o número de espaços vazios causados pelo não cálculo de distancias inversas e 
        # de distancias ao próprio elemento; o (-1) final é para corrigir o index dado que ele começa em zero
        return self.dists[index]
    
#    
#    def nearest_cities(self, already_city = []): #3 cidades
#        dists_x_city = {} 
#        for i in range(1,self.n_total+1):
#            all_dists = []
#            for j in range(1,self.n_total+1):
#                if i != j: all_dists.append(list(self.index_distance(i,j)))
#            best_10 = sorted(all_dists, key=itemgetter(2))
#            best_10 = best_10[:10]
#            nearest_cities = []
#            for city in best_10:
#                if city[0] != i: nearest_cities.append(city[0])
#                else: nearest_cities.append(city[1])
#            dists_x_city[i]= nearest_cities
#        return dists_x_city
#   
        
    def random_init(self):
        islands = []
        while len(islands) < self.islands:
            islands_i = []
            while len(islands_i) < self.island_size:
                islands_i.append(np.random.choice(range(1,self.n_total+1), self.n_total, replace=False))
            islands.append(islands_i)
        return np.asarray(islands)
    
    def nearest_cities_i(self, city, already_city = [], tam = 3): #3 cidades
        dists_city = []
        tam_inicial = tam 
        for dist in self.dists:
            if dist[0] == city:
                if dist[1] not in already_city:
                    dists_city.append(dist)
            elif dist[1] == city:
                if dist[0] not in already_city:
                    dists_city.append(dist)
        best_dists = sorted(dists_city, key=itemgetter(2))
        if len(already_city) > self.n_total - tam_inicial:
            tam = self.n_total - len(already_city)
        best_dists = best_dists[:tam]
        choices = []
        for dist in best_dists:
            if dist[0] == city: choices.append(dist[1])
            else: choices.append(dist[0])
        return choices
                           

    def create_islands(self): 
        islands = []
        while len(islands) < self.islands:
            islands_i = []
            while len(islands_i) < self.island_size:
                already_city = []
                i = randint(1, self.n_total)
                already_city.append(i)
                while len(already_city) < self.n_total:
                    choices = self.nearest_cities_i(i,already_city)
                    i = choice(choices)
                    already_city.append(i)
                islands_i.append(already_city) 
                print(len(islands)," ", len(islands_i))
            islands.append(islands_i)
        return np.asarray(islands)
                     
                
    def fitness(self,sol):
        fitness = self.index_distance(sol[0],sol[-1])[2]
        for i in range(len(sol)-1): fitness += self.index_distance(sol[i],sol[i+1])[2]
        return fitness
    
    def fitness_indivs(self):
        fitness = {}
        index_i = 0
        for i in self.popul:
            fitness_i = {}
            index_j = 0 
            for j in i:
                fitness_i[index_j]=self.fitness(j)
                index_j += 1
            fitness[index_i]=fitness_i
            index_i += 1
        return fitness 

    def best_worst_fitness(self, dictionary, how_many = 4):
        res_best = sorted(dictionary.items(), key = itemgetter(1))[:how_many]
        res_worst = sorted(dictionary.items(), key = itemgetter(1), reverse=True)[:how_many]
        return (res_best,res_worst)
    
    
    def iterDA(self, index, how_many = 4):
        (best_fit, worst_fit) = self.best_worst_fitness(self.fitness_all[index], how_many)
        for i in range(how_many):
            indiv_best = self.popul[index][best_fit[i][0]]
            type_mutation = np.random.choice([1,2,3],p=[0.4,0.3,0.3])
            if type_mutation==1:
                self.popul[index][worst_fit[i][0]] = self.mut2SWAP(indiv_best)
            elif type_mutation==2:
                self.popul[index][worst_fit[i][0]] = self.mut3SWAP(indiv_best)
            else:
                self.popul[index][worst_fit[i][0]] = self.mutInv(indiv_best)
            self.fitness_all[index][worst_fit[i][0]] = self.fitness(self.popul[index][worst_fit[i][0]])
            #tornar isto mais eficiente; ver exemplo do stor
    
    
    def permute_islands(self):
        for i in range(self.islands):
            next_i = i+1
            if next_i == self.islands: next_i = 0
            (best_fit_this, worst_fit_this) = self.best_worst_fitness(self.fitness_all[i],1)
            (best_fit_next, worst_fit_next) = self.best_worst_fitness(self.fitness_all[next_i],1)
            indiv_best = self.popul[i][best_fit_this[0][0]]
            type_mutation = np.random.choice([1,2,3],p=[0.4,0.3,0.3])
            if type_mutation==1:
                self.popul[next_i][worst_fit_next[0][0]] = self.mut2SWAP(indiv_best)
            elif type_mutation==2:
                self.popul[next_i][worst_fit_next[0][0]] = self.mut3SWAP(indiv_best)
            else:
                self.popul[next_i][worst_fit_next[0][0]] = self.mutInv(indiv_best)
            self.fitness_all[next_i][worst_fit_next[0][0]] = self.fitness(self.popul[next_i][worst_fit_next[0][0]])
            
                

    def cycle(self):
        for i in range(self.niter):
            for j in range(self.islands):
                self.iterDA(j)
            if i % self.niter_migrate == 0:
                self.permute_islands()
                print(self.best_current_fit())
            
    
    
    def mut2SWAP(self, individuo):
        i = 0
        j = 0
        while i == j:
            i = randint(0,self.n_total-1)
            j = randint(0,self.n_total-1)
        individuo[i], individuo[j] = individuo[j], individuo[i]
        return individuo
    
    def mut3SWAP(self, individuo):
        i = 0
        j = 0
        k = 0
        while i == j and j == k and i == k:
            i = randint(0,self.n_total-1)
            j = randint(0,self.n_total-1)
            k = randint(0,self.n_total-1)
        i_new,j_new,k_new = 0,0,0
        i_new = choice([j,k])
        if i_new==j:
            j_new=k
            k_new=i
        else:
            j_new=i
            k_new=k
        individuo[i], individuo[j], individuo[k] = individuo[i_new], individuo[j_new], individuo[k_new]
        return individuo
    
    def mutInv(self, individuo):
        i = 0
        j = 0
        while i == j:
            i = randint(0,self.n_total-1)
            j = randint(0,self.n_total-1)
        individuo[i:j] = individuo[i:j][::-1]
        return individuo
        
    
    def best_current_fit(self):
        best_island = 0
        best_indiv = 0
        best_fit = np.inf
        for island in self.fitness_all:
            for indiv in self.fitness_all[island]:
                if self.fitness_all[island][indiv] < best_fit:
                    best_island,best_indiv,best_fit = island,indiv,self.fitness_all[island][indiv]
        return (best_island,best_indiv,best_fit)
    
    
    def export_population(self):
        return self.popul
        
        
         
#def iterGA(pop):
#    p1,p2,f1,f2 = torneio(pop)
#    ind1, ind2 = pop[p1], pop[p2]
#    pop[f1], pop[f2] = mut(ind1), mut(ind2)
        
    
#def mut2SWAP(ind):
#   while I == J:
#       I = select_random_pop(ind)
#       J = select_random_pop(ind)  
#   nind[I], nind[J] = nind[I], nind[I]
#   fitness -= dist(I-1,I) + dist(I,I+1) + dist(J-1,J) + dist(J,J+1)
#   fitness += dist(I-1,J) + dist(J,I+1) + dist(J-1,I) + dist(I,J+1)
#   nind[I],nind[J]=nind[J],nind[I]


def remove_meta(path):
    #remoção dos metadados: as primeiras 7 linhas, bem como remover a última linha que não é numérico
    os.chdir(path)
    try:
        qatar = open("qa194.tsp.txt")
        data = qatar.readlines()
        
        f = open("qatar_file.txt", "w")
        for line in data[7:len(data)-1]: f.write(line)
        
        f.close()  
        qatar.close()
        
    except: 
        print("Erro na limpeza de metadados")




if __name__ == "__main__":
    filepath = "D:\\UMinho\\2ano\\Sistemas_Intelegentes\\avaliacao_continua_2"
    #data_population = population
    problem = Qatar(filepath)
    #popul = problem.export_population()
    problem.cycle()
    #print(problem.nearest_cities_i(177,[181]))

    